package org.anchorz.java_drive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaDriveApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaDriveApplication.class, args);
	}

}
