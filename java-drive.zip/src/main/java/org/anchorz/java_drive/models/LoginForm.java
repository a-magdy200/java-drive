package org.anchorz.java_drive.models;

public class LoginForm {
    public String email;
    public String password;
}
