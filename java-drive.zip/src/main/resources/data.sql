INSERT INTO users (firstname, lastname, username, password, salt) VALUES
    ('test', 'user', 'testuser', 'nxUqMDSeiJCDaOY26Kmx/A==', 'x2hqNNU9i6iF9sQZ86Brtw==');