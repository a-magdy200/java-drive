package org.anchorz.java_drive;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CredentialsTests {
    @FindBy(id = "add_new_credentials")
    private WebElement addNewCredentialsButton;

}
